# Wprowadzenie do sztucznej inteligencji

## Student

Imię: Bartłomiej

Nazwisko: Krawczyk

Numer indeksu: 310774
